import UIKit

class FourFeatures{
    var Color:String = "Black and Yellow"
    var TintedWindows:String = "Yes?"
    var Sunroof:String = "Yes"
    var bluetooth = "Yes"
    
    func whatFeatures(Color:String, TintedWIndows:String, Sunroof:String, bluetooth:String) -> String{
        let statement = "My dream car is a " + Color + " Lamborghini Urus that has a " + Sunroof + " and some " + TintedWIndows + " and even though it is a given I also want to make sure it has" + bluetooth
        return statement
}
}

var ChoseFeatures = FourFeatures()

var final = ChoseFeatures.whatFeatures(Color: "Black and Yellow", TintedWIndows: "Light tinted windows", Sunroof: "Large sunroof", bluetooth: " a bluetooth system")
print(final)
